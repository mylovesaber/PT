#pragma once

#define PEERID_PREFIX             "-TR2940-"
#define USERAGENT_PREFIX          "2.94"
#define VCS_REVISION              "d8e60ee44f"
#define VCS_REVISION_NUM          d8e60ee44f
#define SHORT_VERSION_STRING      "2.94"
#define LONG_VERSION_STRING       "2.94 (d8e60ee44f)"
#define VERSION_STRING_INFOPLIST  2.94
#define BUILD_STRING_INFOPLIST    14714.2.94
#define MAJOR_VERSION             2
#define MINOR_VERSION             94
#define TR_STABLE_RELEASE         1
